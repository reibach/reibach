package reibach.server;


import java.text.DecimalFormat;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;

class HalloWelt
{
	public static void main(String[] args)
	{
		String result = "123585.5455"; // der Klassiker
		DecimalFormat df = new DecimalFormat("#.##");
		System.out.println("asasasasa" + df.format(result));

    // System.out.println("Hallo Welt!");
    // System.out.println("Hallo Welt!");
	}
}
