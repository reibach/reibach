package reibach.rmi;

import java.rmi.RemoteException;

import de.willuhn.datasource.rmi.DBObject;

/***
 * 
 * 
 * 
 * @author guenter
 *
 *
	  CREATE TABLE customer (
	  id NUMERIC default UNIQUEKEY('customer'),
	  company varchar(27) NOT NULL,
	  title varchar(27) NOT NULL,
	  firstname varchar(27) NOT NULL,
	  lastname varchar(27) NOT NULL,
	  street varchar(27) NOT NULL,
	  housenumber varchar(27) NOT NULL,
	  zipcode varchar(5) NOT NULL,
	  place varchar(27) NOT NULL,
	  email varchar(100) NOT NULL,
	  tel varchar(27) NOT NULL,
	  fax varchar(27) NOT NULL,
	  mob varchar(27) NOT NULL,
	  UNIQUE (id),
	  PRIMARY KEY (id)
	);
 */

public interface Customer extends DBObject
{

	/**
	 * Returns the name of this task.
   * @return name of the task.
   * @throws RemoteException
   */
  public String getLastname() throws RemoteException;

	/**
	 * Stores the name of the task.
   * @param name name of the task.
   * @throws RemoteException
   */
  public void setLastname(String name) throws RemoteException;
  

}

