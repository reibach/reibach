<?php
use yii\helpers\Html;
?>  

<?=$model->id;?> 
<?=$model->name;?> 
<?=$model->bill_id;?>
