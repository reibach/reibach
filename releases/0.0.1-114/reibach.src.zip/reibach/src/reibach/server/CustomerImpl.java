package reibach.server;

import java.rmi.RemoteException;

import reibach.Settings;
import reibach.rmi.Customer;

import de.willuhn.datasource.db.AbstractDBObject;
import de.willuhn.datasource.rmi.ObjectNotFoundException;
import de.willuhn.logging.Logger;
import de.willuhn.util.ApplicationException;

/**
 * Implementation of the task interface.
 * Look into ProjectImpl for more code comments.
 */
public class CustomerImpl extends AbstractDBObject implements Customer
{

  /**
   * ct.
   * @throws RemoteException
   */
  public CustomerImpl() throws RemoteException
  {
    super();
  }

  /**
   * @see de.willuhn.datasource.db.AbstractDBObject#getTableName()
   */
  protected String getTableName()
  {
  	// this is the sql table name.
    return "task";
  }

  /**
   * @see de.willuhn.datasource.GenericObject#getPrimaryAttribute()
   */
  public String getPrimaryAttribute() throws RemoteException
  {
  	// our primary attribute is the name.
    return "lastname";
  }

  /**
   * @see de.willuhn.datasource.db.AbstractDBObject#deleteCheck()
   */
  protected void deleteCheck() throws ApplicationException
  {
  }

  /**
   * @see de.willuhn.datasource.db.AbstractDBObject#insertCheck()
   */
  protected void insertCheck() throws ApplicationException
  {
		try {
			if (getLastname() == null || getLastname().length() == 0)
				throw new ApplicationException(Settings.i18n().tr("Please enter a name"));

		}
		catch (RemoteException e)
		{
			Logger.error("insert check of customer failed",e);
			throw new ApplicationException(Settings.i18n().tr("unable to store customer, please check the system log"));
		}
  }

  /**
   * @see de.willuhn.datasource.db.AbstractDBObject#updateCheck()
   */
  protected void updateCheck() throws ApplicationException
  {
  	// same as insertCheck
  	insertCheck();
  }

  /**
   * @see reibach.rmi.Task#getLastname()
   */
  public String getLastname() throws RemoteException
  {
    return (String) getAttribute("lastname");
  }

  /**
   * @see reibach.rmi.Task#setName(java.lang.String)
   */
  public void setLastname(String lastname) throws RemoteException
  {
  	setAttribute("lastname",lastname);
  }

}

